package it.uniupo.algo2.grafi;

import it.uniupo.libPrimoLab.Edge;
import it.uniupo.libPrimoLab.GraphInterfaceEs;

public class DirectedGraph implements GraphInterfaceEs{
	/******************************
	 * aggiungete le variabili di istanza che vi servono
	 * io ce ne ho messa una
	 ******************************/
	private int numberOfEdges;

	//costruisce un grafo con nVert nodi e nessun arco
	public DirectedGraph(int nVert) { // creates a graph with nVert nodes and no
										// edges
		/**********************
		 * to do
		 **********************/
	}
	
	//restituisce il numero di nodi del gafo
	@Override
	public int getOrder() {
		/**********************
		 * to do
		 **********************/
		return 0;
	}

	//restituisce il numero di archi del grafo
	@Override
    public int getEdgeNum(){
		/*****************************************************
		 * metodo già implementato, ma va gestita correttamente la 
		 * variabile di istanza numberOfEdges nel resto del codice
		 *****************************************************/
    	return numberOfEdges;
    }; 

    //aggiunge un arco non pesato al grafo
	@Override
	public void addEdge(int tail, int head) {
		/**********************
		 * to do
		 **********************/
	}
	
	//aggiunge un arco pesato al grafo
	@Override
	public void addEdge(int tail, int head, int weight) { 
		/**********************
		 * to do later
		 **********************/
	}
	
	//restituisce true se (u,v) e' un arco del grafo, false altrimenti
	@Override
	public boolean hasEdge(int u, int v) {
		/**********************
		 * to do
		 **********************/
		return false;
	}

	//restituisce i nodi adiacenti al nodo dato
	@Override
	public Iterable<Integer> getNeighbors(int u) { 
		/**********************
		 * to do
		 * ad esempio create una ArrayList<Integer>, riempitela opportunamente
		 * e restituitela (ma potete usare una qualunque altra struttura Iterable)
		 **********************/
		return null;
	}

	//restituisce gli archi uscenti dal nodo dato
	@Override
	public Iterable<Edge> getIncidentEdges(int u) { 
		/**********************
		 * to do
		 * ad esempio create una ArrayList<Edge>, riempitela opportunamente
		 * e restituitela (ma potete usare una qualunque altra struttura Iterable)
		 **********************/
		return null;
	}
	
//	  /**
//  * Removes the specified edge from the graph (if the egde exists)
//  * @param tail tail of the edge to be removed
//  * @param head head of the edge to be removed
//  */
// public void removeEdge(int tail, int head){ //delete edge (tail,head)
// 	/**********************
//		 * to do
//		 **********************/
// }; 


}
